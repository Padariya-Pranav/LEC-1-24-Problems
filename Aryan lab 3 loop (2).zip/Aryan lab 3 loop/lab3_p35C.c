#include <stdio.h>
int main() {
    int i, j;
    for (i = 1; i <= 2; i++) {
        for (j = 1; j <= 3; j++) {
            printf("%d %d\n", i, (j < 3) ? j : 2);
        }
    }
    return 0;
}
