#include <stdio.h>
int main() {
    int i;
    for (i = 5; i >= 3; i--) {
        printf("%d 1\n", i);
    }
    printf("3 2\n");
    return 0;
}
