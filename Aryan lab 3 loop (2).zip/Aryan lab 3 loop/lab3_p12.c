#include<stdio.h>
void main()
{

    int a=1,b;
    printf("Enter the value of b\n");
    scanf("%d", &b);
    do
    {
    
        printf("PRANAV \n" );
        a++;
    } while (a<=b);
    
    
}

