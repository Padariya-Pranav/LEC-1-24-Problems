#include<stdio.h>
void main()

{
    int a = 1;
    int x,sum=0;
    printf("Enter the value of number you want the sum \n");
    scanf("%d", &x);

    for(a==1;a<=x; a++)
    {
        if(a%2!=0)
        {
        sum=sum+a;
        }
    }

     printf("The Sum of %d odd natural number is %d\n", x,sum);
}