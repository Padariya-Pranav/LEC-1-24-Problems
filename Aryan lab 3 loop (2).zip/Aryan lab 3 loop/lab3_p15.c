#include <stdio.h>
void main() {
    int i, n, sum = 0,lim;
    float avg;
    printf("enter any number :  ");
    scanf("%d",&lim);
    printf("Input the %d numbers : \n",lim);

    for (i = 1; i <=lim; i++)
    {
        printf("Number %d:", i);
        scanf("%d", &n);
        sum = sum + n;
    }

    avg = sum / 10.0;

    printf("The sum of 10 no is : %d\n", sum);
    printf("The Average is : %f\n", avg);
}