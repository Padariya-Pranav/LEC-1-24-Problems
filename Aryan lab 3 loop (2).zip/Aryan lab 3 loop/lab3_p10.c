#include<stdio.h>
void main()

{
    int a,b=1,c;

    printf("Enter the number you want factorial value of:\n");
    scanf("%d", &c);

    for(a=1;a<=c;a++)
    {
        b=b*a;

    }

    printf("The value of  %d! is %d\n", c,b);

}