#include <stdio.h>

int main() 
{
    int nu;

    printf("Enter a number: ");
    scanf("%d", &nu);

    printf("Digits separated: ");

    while (nu > 0) 
    {
        printf("%d", nu % 10);
        nu = nu / 10;

        if (nu > 0)
            printf(", ");
    }

    printf("\n");

    return 0;
}