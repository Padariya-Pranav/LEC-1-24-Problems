#include <stdio.h>

int main() {
    int i, number;
    int po= 0, ne = 0, zero = 0;

    for (i = 1; i <= 12; i++) 
    {
        printf("Enter number %d: ", i);
        scanf("%d", &number);

        if (number > 0)
            po=po+1;
        else if (number < 0)
            ne=ne+1;
        else
            zero=zero+1;
    }

    printf("Positive numbers: %d\n", po);
    printf("Negative numbers: %d\n", ne);
    printf("Zeroes: %d\n", zero);

    return 0;
}