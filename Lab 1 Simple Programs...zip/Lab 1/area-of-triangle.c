#include<stdio.h>

int main()
{
    int h,l,area;

    printf("Enter the value of height:\n");
    scanf("%d", &h);

    printf("Enter the value of length:\n");
    scanf("%d", &l);

    area=h*(l/2);

    printf("The area of triangle with height %d and length %d is :%d", h,l,area);

}