#include<stdio.h>

int main()
{
    float P, R, N, I;
    printf("Enter the value of Principle Amount\n");
    scanf("%f", &P);

    printf("Enter the value of Rate Of Interest \n");
    scanf("%f", &R);

    printf("Enter the value of Number of Years of Term\n");
    scanf("%f", &N);

    I=P*R*N/100;

    printf("The Interest on the entered value P: %.2f , R: %.2f , N: %.2f is = %.2f", P, R, N ,I);


}