#include<stdio.h>
// important code
int main()
{
    float d,Ru,p ;
    
    printf("Enter the value of Dollar you want to convert to Pound \n");
    scanf("%f", &d);
    Ru= d*48;
    
    p=Ru/70;

    printf(" %.3f Dollar = %-6f Pound ",d, p );

}