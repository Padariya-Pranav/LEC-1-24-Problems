#include<Stdio.h>

int main()
{
    float a, b;

    printf("Enter the  numbers of minutes you want to convert to hours \n");
    scanf("%f",&a);

    printf("%.2f Minutes = %.1f Hour", a , a/60);
}