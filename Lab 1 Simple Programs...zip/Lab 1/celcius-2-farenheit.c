#include<stdio.h>

int main()

{
    int a ;
    printf("Enter the value of temperature in celcius you wan to convert to farenheit\n");
    scanf("%d", &a);

    printf("The Farenheit value of %d is: %d \n" ,a, ((9*a/5)+32));

}