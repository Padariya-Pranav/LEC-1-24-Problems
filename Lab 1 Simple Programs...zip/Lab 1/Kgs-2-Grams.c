#include<stdio.h>
int main()

{
    float a;

    printf("Enter the Weight(In Kgs) You want to convert to Weight(In Grams)\n");
    scanf("%f", &a);

    printf("%.2f Kgs = %.1f Grams", a, a*1000);
    return 0;
}