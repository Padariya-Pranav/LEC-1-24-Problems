#include<stdio.h>
int  main()

{
    int a ;

    printf("Enter the value of hour you want to convert to minutes\n");
    scanf("%d", &a);

    printf("The total number of minutes in %d hour is %d", a, a*60);

}