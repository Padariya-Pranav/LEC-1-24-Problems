#include<stdio.h>
int main()

{
    int salary,allowance,deduction,a;

    printf("Enter the amount of the salary:\n");
    scanf("%d", &salary);

    allowance=(10*salary/100);
    deduction=(3*salary/100);

    printf("The net salary in hand will be :%d", salary+allowance-deduction);
    return 0;
}