#include<stdio.h>
int main()

{
    int r,area , pi;

    pi=22/7;
    printf("Enter the value of Radius\n");
    scanf("%d", &r);

    area=pi*r*r;
    printf("Area Of circle with Radius %d is :%d", r,area);

}