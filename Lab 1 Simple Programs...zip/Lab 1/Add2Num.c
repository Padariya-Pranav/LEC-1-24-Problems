#include<stdio.h>

int main()
{
    int a , b;

    printf("Enter the value of A:\n");
    scanf("%d", &a);

    printf("Enter the value of B:\n");
    scanf("%d", &b);

    printf("Sum of A and B is = %d", a+b);

    
}