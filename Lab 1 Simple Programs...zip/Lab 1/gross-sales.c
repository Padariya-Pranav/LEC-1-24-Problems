#include<stdio.h>

int main()
{
    int a, sales, discount;

    printf("Enter the value of amount of the sales:\n");
    scanf("%d", &sales);

    discount= (sales*10)/100 ;
    
    printf("The total left amount after discount is :%d", sales-discount);

}