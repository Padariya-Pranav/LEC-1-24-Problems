#include<stdio.h>

int main()
{
    float a;

    printf("Enter the value of rupees y0u want to convert to dollar\n");
    scanf("%f", &a);

    printf(" %.0f Rupees = %.3f Dollar", a, a/48);

}