#include<stdio.h>
int main()
{
    int maths , geology, computer;

    printf("Enter the marks obtained in Maths:\n");
    scanf("%d", &maths);

    printf("Enter the marks obtained in Geology:\n");
    scanf("%d", &geology);

    printf("Enter the marks obtained in Computer:\n");
    scanf("%d", &computer);

    printf("Average of All the subjects is %d\n", (maths+geology+computer)/3);

    printf("Total Marks Obtained in the examination: %d", maths+geology+computer);

}