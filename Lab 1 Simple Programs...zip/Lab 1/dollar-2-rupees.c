
#include<stdio.h>

int main()
{
    int a,b;
    printf("Enter the value of dollar to convert to rupees\n");
    scanf("%d", &a);

    printf("%d Dollar = %d Rupees", a ,a*48);

}