#include<stdio.h>

void main()
{
    float a,b;
    

    printf("Enter the value of A and B :\n");
    scanf("%f %f", &a,&b);

    printf("Addition of two numbers a and b is %.2f\n", a+b);
    printf("Subtraction of two numbers a and b is %.2f\n", a-b);
    printf("Multiplication of two numbers a and b is %.2f\n", a*b);
    printf("Division of two numbers a and b is %.2f\n", a/b);

}