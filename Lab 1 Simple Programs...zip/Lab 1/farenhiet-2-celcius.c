#include<stdio.h>

int main()
{
    int a, ans;

    printf("Enter the value of temperature in farehniet to convert it in celcius\n");
    scanf("%d", &a);

    ans= ((a-32)*5/9);
    printf("The celcius value of %d farenheit is : %d", a, ans);
    return 0;
    
}