#include<stdio.h>

int main()
{
    int l,b, area, pe;

    printf("Enter the value of length and breadth of the rectangle\n");

    scanf("%d %d",&l,&b);

    area= l*b;
    pe=(2*(l+b));
    printf("The area of ractangle with length %d and breadth %d is :%d\n",l,b,area );
    printf("The Perimeter of rectangle with length %d and breadth %d is :%d\n", l, b, pe);


}
