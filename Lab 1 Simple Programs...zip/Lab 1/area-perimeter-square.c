#include<stdio.h>
int main()
{
    int area,pe, l ;

    printf("Enter the value of Length:\n");
    scanf("%d", &l);

    area= l*l;
    printf("The area of square with length %d is : %d meter-square\n" , l, area);

    pe= 4*l;
    printf("The perimeter of the square with length %d is %d meter\n", l, pe);


}