#include<stdio.h>

int main()

{
    int a,b,c;

    printf("Enter the value of a and b \n");
    scanf("%d %d", &a, &b);
    
    c=a;
    a=b;
    b=c;

    printf("The value of A after swapping is %d\n", a);
    printf("The value of b after swapping is %d\n", b);

}