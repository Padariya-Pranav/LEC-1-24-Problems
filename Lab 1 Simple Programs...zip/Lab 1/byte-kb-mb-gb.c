#include<stdio.h>
int main()

{
    float byte,kb,mb,gb;

    printf("Enter the value of Byte\n");
    scanf("%f", &byte);
    kb = byte/1024;
    mb= kb/1024;
    gb= mb/1024;
    printf("%f byte = %f kb\n", byte, kb );
    printf("%f kb = %f mb\n", kb, mb  );
    printf("%f mb = %10f gb\n", mb, gb  );

    return 0;
}