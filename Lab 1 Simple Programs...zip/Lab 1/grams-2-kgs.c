#include<stdio.h>
int main()

{
    float a, b;
    printf("Enter the Weight(In Grams) you want to convert to Weight(In Kgs) \n");
    scanf("%f", &a);

    printf("%.2f Grams = %.3f Kgs", a, a/1000);
    return 0;

}